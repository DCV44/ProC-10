var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["b0843c58-dd6e-445a-b314-52b15448120c","edc07c6e-fb84-4a46-8484-a2110e331844","8e49889a-3180-41b3-8ad4-a6035e0073ef","1a70b25f-1df2-4c75-a73f-6c40d37c836b"],"propsByKey":{"b0843c58-dd6e-445a-b314-52b15448120c":{"name":"Cancha","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"Xu7oEOPbVlzdM2PW.d9EAWQQGVMn1Fj1","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/b0843c58-dd6e-445a-b314-52b15448120c.png"},"edc07c6e-fb84-4a46-8484-a2110e331844":{"name":"cancha2","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"6J0HrI8B4sjuhSnAxHLit_y1ErJavJsc","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/edc07c6e-fb84-4a46-8484-a2110e331844.png"},"8e49889a-3180-41b3-8ad4-a6035e0073ef":{"name":"laq1","sourceUrl":null,"frameSize":{"x":14,"y":22},"frameCount":2,"looping":true,"frameDelay":12,"version":"Rl4a1Krn8OFckj5uX4p0tyGfxh6VSd5t","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":22},"rootRelativePath":"assets/8e49889a-3180-41b3-8ad4-a6035e0073ef.png"},"1a70b25f-1df2-4c75-a73f-6c40d37c836b":{"name":"fubooo.png_1_copy_1","sourceUrl":null,"frameSize":{"x":288,"y":480},"frameCount":2,"looping":true,"frameDelay":12,"version":"yb.ofU3dJ7yHuwLPbPa_YBgxxo54nVKM","loadedFromSource":true,"saved":true,"sourceSize":{"x":576,"y":480},"rootRelativePath":"assets/1a70b25f-1df2-4c75-a73f-6c40d37c836b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gameState = "serve"



var laq = createSprite(100,300,40,10);
 laq.shapeColor = "darkgreen";
 
var op = createSprite(500,500,40,10);
 op.shapeColor = "red";
 
 var laq1 = createSprite(200,100,40,10);
 laq1.shapeColor = "darkgreen";


var ball2 = createSprite(200,200,10,10);
 ball2.shapeColor = "darkgreen";

//canchas
var goal1=createSprite(200,18,100,30);
goal1.shapeColor=("yellow");

var goal2=createSprite(200,382,100,30);
goal2.shapeColor=("yellow");

//bordes
var boundary1 = createSprite(200,0,400,10);
boundary1.shapeColor = "white";
var boundary2 = createSprite(200,400,400,10);
boundary2.shapeColor = "white";
var boundary3 = createSprite(0,200,10,400);
boundary3.shapeColor = "white";
var boundary4 = createSprite(400,200,10,400);
boundary4.shapeColor = "white";

//pelota y jugadores
var ball = createSprite(200,200,10,10);
ball.shapeColor = "white";

var player2 = createSprite(200,350,50,10);
 player2.shapeColor = ("yellow");
var playerbot = createSprite(200,50,50,10);
  playerbot.shapeColor = ("yellow");
  
  
  //score

var botScore= 0;
var player= 0;

//estados




function draw() {
  background("darkgreen");
  drawSprites();
  
  

  
  //estados
  
  
  if (gameState == "serve" ){
    
    stroke("white");
    textSize(17);
    text ("preciona ENTER para jugar ",130,300);
    
  stroke("white");
    textSize(17);
    text ("hice el proyecto C-7 y C-8 en uno",130,190);
    
    
  if(keyDown("enter")){
    ball.velocityX = 3;
    ball.velocityY = 2;
    
    
    ball2.velocityX = -3;
    ball2.velocityY = 2;

    gameState = "play";
  }
    
    
    
    
  }


// Play

if (gameState == "play"){
  
    /* movimiento de los jugadores*/
  
  if (keyDown("LEFT_ARROW")){
    player2.x=player2.x-10;
  }
  
  if (keyDown("RIGHT_ARROW")){
    player2.x=player2.x+10;
  }
  
if (ball.isTouching(op) || player == "5" || botScore == "5"){
  gameState = "end";
}
  
  
playerbot.x=ball2.x;
  
}


//end

if (gameState == "end"){
  
  
  ball.velocityY=0;
  ball.velocityX=0;
  
  stroke("red");
  textSize(30);
  text ("fin del jueguo ",200,200);
}
  
  
  
  
  // Tabla de puntuacion



  textSize(18);
  stroke("white");
  text(botScore,25,225);
  text(player,25,185);
  
  //puntuacion
  

if (ball.isTouching(goal1)){
 
   botScore=botScore+1;
}
      
  
  
         if(ball.isTouching(goal2))
      {
       player=player+1;
        
        
      }
  
  
  

  
    //linea
  
     for (var i = 0; i < 400; i=i+20) {
    line(i,200,i+10,200);
    line.shapeColor="black";
     }
  
  

  
  
  //rebote
  
  createEdgeSprites();
  
  ball.bounceOff(player2);
  ball.bounceOff(playerbot);
  
  ball.bounceOff(boundary1);
  ball.bounceOff(boundary2);
  ball.bounceOff(boundary3);
  ball.bounceOff(boundary4);
  
  ball.bounceOff(goal1);
  ball.bounceOff(goal2);
  
  
  
  
 ball2.bounceOff(goal1);
 ball2.bounceOff(goal2);
 
 ball2.bounceOff(player2);
 ball2.bounceOff(playerbot);
  
  ball2.bounceOff(boundary1);
  ball2.bounceOff(boundary2);
  ball2.bounceOff(boundary3);
  ball2.bounceOff(boundary4);
  
ball2.bounceOff(laq);
ball2.bounceOff(laq1);
  
  
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
